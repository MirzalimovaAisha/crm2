import React from 'react'

const Attandance = () => {
  return (
    <div>AttandanceComponent</div>
  )
}

export default Attandance