import React from "react";
import { GroupName, GroupsCard, Line, StartDate } from "../teachers/style";
import {
  HistoryCardData,
  HistoryCardMyName,
  HistoryCardTop,
  HistoryGap,
} from "./style";

function GroupHistory({ data }) {
  return (
    <div>
      History
    </div>
  );
}

export default GroupHistory;
