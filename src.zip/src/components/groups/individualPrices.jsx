import React from 'react'

const IndividualPrices = () => {
  return (
    <div>IndividualPrices</div>
  )
}

export default IndividualPrices