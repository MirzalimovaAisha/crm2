export const commentData = {
    maindata: [
        {
            id: 1,
            comment: {
                comment: "Lorem Ipsum is simply dummy text of the printing and typesetting industry.",
                creator: 'Mina Yoon',
                date: '05.31.2024',
                time: '21:32'
            }
        },
        {
            id: 2,
            comment: {
                comment: "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s",
                creator: 'park Seajun',
                date: '05.31.2024',
                time: '21:32'
            }
        },
    ]
}