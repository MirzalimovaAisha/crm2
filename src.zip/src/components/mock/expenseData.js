export const expenseData = {
    maindata: [
        {
            id: 1,
            expense: {
                amount: '25 000 000',
                category: 'Salary',
                description: 'May oyi uchun',
                date: '06.06.2024'
            }
        },
        {
            id: 2,
            expense: {
                amount: '25 000 000',
                category: 'Salary',
                description: 'Lorem ipsum dolor',
                date: '06.06.2024'
            }
        },
        {
            id: 3,
            expense: {
                amount: '25 000 000',
                category: 'Salary',
                description: 'Oylik',
                date: '06.06.2024'
            }
        },
    ]
}