export const incomeData = {
    maindata: [
        {
            id: 1,
            income: {
                won: '51 000 000',
                group: 'IT Bootcamp',
                student: 'Qurbonsaid Rayimov',
                attendDate: '06.06.2024',
                paymentDate: '08.06.2024'
            }
        },
        {
            id: 2,
            income: {
                won: '51 000 000',
                group: 'IT Bootcamp',
                student: 'Qurbonsaid Rayimov',
                attendDate: '06.06.2024',
                paymentDate: '08.06.2024'
            }
        },
        {
            id: 3,
            income: {
                won: '51 000 000',
                group: 'IT Bootcamp',
                student: 'Aisha Mirzalimova',
                attendDate: '06.06.2024',
                paymentDate: '08.06.2024'
            }
        },
        {
            id: 4,
            income: {
                won: '51 000 000',
                group: 'IT Bootcamp',
                student: 'Qurbonsaid Rayimov',
                attendDate: '06.06.2024',
                paymentDate: '08.06.2024'
            }
        },
        {
            id: 5,
            income: {
                won: '51 000 000',
                group: 'IT Bootcamp',
                student: 'Qurbonsaid Rayimov',
                attendDate: '06.06.2024',
                paymentDate: '08.06.2024'
            }
        },
        {
            id: 6,
            income: {
                won: '51 000 000',
                group: 'IT Bootcamp',
                student: 'Aisha Mirzalimova',
                attendDate: '06.06.2024',
                paymentDate: '08.06.2024'
            }
        },
        {
            id: 7,
            income: {
                won: '51 000 000',
                group: 'IT Bootcamp',
                student: 'Qurbonsaid Rayimov',
                attendDate: '06.06.2024',
                paymentDate: '08.06.2024'
            }
        },
        {
            id: 8,
            income: {
                won: '51 000 000',
                group: 'IT Bootcamp',
                student: 'Qurbonsaid Rayimov',
                attendDate: '06.06.2024',
                paymentDate: '08.06.2024'
            }
        },
    ]
}