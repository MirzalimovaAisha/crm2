export const studentGroupData = {
    maindata: [
        {
            id: 1,
            group: {
                date: '2023.09.01',
                amount: '- 0',
                group: 'New elementary',
                receiver: 'Ali Mirzo',
            }
        },
        {
            id: 2,
            group: {
                date: '2023.09.01',
                amount: '- 200 000',
                group: 'Texts for test and long title',
                receiver: 'Ali Mirzo',
            }
        },
        {
            id: 3,
            group: {
                date: '2023.09.01',
                amount: '+ 100 000',
                group: 'Space',
                receiver: 'Ali Mirzo',
            }
        },
    ]
}