import React from "react";

// =========== styles =============
import {
    AddLead,
    Icon,
    LeadsContainer,
    LeadsNavbar,
    Menu,
    MenuWrapper,
    ResetFilter,
    SearchSection,
    SearchSectionOption,
    SearchStudent,
} from "./style";

// ============ img =============
import vMenu from "../../assets/vMenu.svg";
import gridMenu from "../../assets/gridMenu.svg";
import searchIcon from "../../assets/search-icon.svg";
import resetIcon from "../../assets/reset-icon.svg";
import plusIcon from "../../assets/plus-icon.svg";
// active
import vMenuActive from "../../assets/vMenu-active.svg"
import gridMenuActive from "../../assets/gridMenu-active.svg"

import GridMenu from "./gridMenu";
import VMenu from "./vMenu";
import AddNewLeadModal from "./addNewLeadModal";

function Leads() {
    const [open, setOpen] = React.useState(false);
    const [activeMenu, setActiveMenu] = React.useState(true);
    const [activeVMenu, setActiveVMenu] = React.useState(false);
    const [activeGridMenu, setActiveGridMenu] = React.useState(true);

    function handleMenuClick() {
        setActiveMenu(true);
        setActiveVMenu(false);
        setActiveGridMenu(true); // gridMenu 활성화
    }

    function handleGridMenu() {
        setActiveMenu(false);
        setActiveVMenu(true);
        setActiveGridMenu(false); // gridMenu 비활성화
    }

    return (
        <div style={{display:"flex", justifyContent:"center"}}>
            <LeadsContainer>
                <LeadsNavbar>
                    <MenuWrapper>
                        <Menu
                            $vmenu
                            onClick={handleGridMenu}
                            active={!activeMenu}
                        >
                            <Icon
                                src={activeVMenu  ?  vMenuActive : vMenu}
                                alt="Vertical Menu"
                                active={!activeMenu}
                            />
                        </Menu>
                        <Menu onClick={handleMenuClick} active={activeMenu}>
                            <Icon
                                src={activeGridMenu ? gridMenuActive : gridMenu}
                                alt="Grid Menu"
                                active={activeMenu}
                            />
                        </Menu>
                    </MenuWrapper>

                    <SearchStudent>
                        <img src={searchIcon} alt="" />
                        <input type="text" placeholder="Search student..." />
                    </SearchStudent>

                    <SearchSection>
                        <SearchSectionOption value="1">
                            Search lead section
                        </SearchSectionOption>
                        <SearchSectionOption value="2">
                            Elementary
                        </SearchSectionOption>
                        <SearchSectionOption value="3">
                            Beginner
                        </SearchSectionOption>
                    </SearchSection>

                    <SearchSection>
                        <SearchSectionOption value="1">
                            From where
                        </SearchSectionOption>
                        <SearchSectionOption value="2">
                            Telegram
                        </SearchSectionOption>
                    </SearchSection>

                    <ResetFilter>
                        <img src={resetIcon} alt="" />
                        Reset filter
                    </ResetFilter>

                    <AddLead onClick={() => setOpen(true)}>
                        <img src={plusIcon} alt="" />
                        Add lead
                    </AddLead>
                </LeadsNavbar>

                {activeMenu ? <GridMenu /> : <VMenu />}

                <AddNewLeadModal open={open} setOpen={setOpen} />
            </LeadsContainer>
        </div>
    );
}

export default Leads;
